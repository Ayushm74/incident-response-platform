package com.incident.dto;

import com.incident.entity.Incident;
import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class IncidentCreateRequest {
    @NotNull(message = "Incident type is required")
    private Incident.IncidentType type;

    @NotBlank(message = "Description is required")
    @Size(min = 10, max = 2000, message = "Description must be between 10 and 2000 characters")
    private String description;

    @NotNull(message = "Latitude is required")
    @DecimalMin(value = "-90.0", message = "Latitude must be between -90 and 90")
    @DecimalMax(value = "90.0", message = "Latitude must be between -90 and 90")
    private Double latitude;

    @NotNull(message = "Longitude is required")
    @DecimalMin(value = "-180.0", message = "Longitude must be between -180 and 180")
    @DecimalMax(value = "180.0", message = "Longitude must be between -180 and 180")
    private Double longitude;

    private String address;

    private Double gpsAccuracy;
}


