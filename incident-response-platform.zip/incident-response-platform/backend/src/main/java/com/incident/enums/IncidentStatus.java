package com.incident.enums;

public enum IncidentStatus {
    UNVERIFIED,
    VERIFIED,
    IN_PROGRESS,
    RESOLVED,
    FALSE
}
